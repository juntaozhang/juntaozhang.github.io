# Hadoop branch-3.1 基线 RPC 性能/稳定性 fix 全量复审

**基线**：`680dac26d80`（branch-3.1）→ `a3d8749b8ca`（branch-3.1 tip）
**范围**：`range_jira.txt` 822 个 HDFS-/HADOOP- commit（已去文档/构建/Ozone/Revert）

## 方法（两步）

1. **标题人工标注** → `triage_step1.tsv`：KEEP 232 / DROP 590（misc 266、feat 98、cli 66、test 61、sec 46、fs 49、cpp 4）
2. **patch 分析** → `triage_step2.tsv`：RELEVANT **172** / DROP 47 / KNOWN 13。RELEVANT 均写 `<JIRA>.md` 分析，并在基线 worktree（`/tmp/hadoop-base` @680dac26）实测 `git apply --check`

## 最终清单（172 个 RELEVANT，按评级排序）

| 评级 | JIRA | commit | apply 到基线 680dac26 | 说明 |
|---|---|---|---|---|
| 高 | [HADOOP-16385](HADOOP-16385.md) | `3ab475377a9` | 见文档 |  |
| 高 | [HADOOP-17068](HADOOP-17068.md) | `1fe15113cf4` | clean | NN 换 IP 客户端永久失败修复 |
| 高 | [HDFS-10240](HDFS-10240.md) | `865650052b0` | clean | close 与 recoverLease 竞态：UNDER_RECOVERY 块拒绝 commit，防 missing block |
| 高 | [HDFS-10477](HDFS-10477.md) | `084fb9de22a` | 冲突 | decommission 整架 DN 持写锁遍历全块列表致 NN failover，改按 storage 分批+锁间 sleep |
| 高 | [HDFS-12914](HDFS-12914.md) | `026cc2647d4` | clean | block report lease 校验上移到 RPC 入口前，修复同 RPC 多 storage report 被丢导致 missing blocks |
| 高 | [HDFS-13101](HDFS-13101.md) | `d18b720c705` | 见文档 |  |
| 高 | [HDFS-13359](HDFS-13359.md) | `f2007818fc9` | 见文档 |  |
| 高 | [HDFS-14429](HDFS-14429.md) | `608e7044a53` | 见文档 |  |
| 高 | [HDFS-14941](HDFS-14941.md) | `c6cbf67b82c` | 见文档 |  |
| 高 | [HDFS-15012](HDFS-15012.md) | `280cd6dd1ee` | 见文档 |  |
| 高 | [HDFS-15210](HDFS-15210.md) | `379a7a57267` | clean | EC 写挂起修复 |
| 高 | [HDFS-15323](HDFS-15323.md) | `8358d7c1759` | 冲突 | SBN 切 active tail 不足 |
| 高 | [HDFS-15421](HDFS-15421.md) | `d26dcf66869` | 冲突 | IBR 泄漏致 SBN 卡 safe mode |
| 高 | [HDFS-15641](HDFS-15641.md) | `eb909fd726a` | clean | refreshNameNode 死锁 |
| 高 | [HDFS-15644](HDFS-15644.md) | `7f3645ec5ba` | clean | 坏卷致 block report 残缺 |
| 高 | [HDFS-15704](HDFS-15704.md) | `a23faaec184` | 冲突 | lease monitor 死循环，删 sortedLeases |
| 高 | [HDFS-15719](HDFS-15719.md) | `13768fe6f0c` | 冲突 | JN/HTTP idle timeout 默认 1s→60s，防双 NN 崩溃 |
| 高 | [HDFS-15915](HDFS-15915.md) | `49490af23c7` | 冲突 | 异步 edit log txid 竞态 |
| 中 | [HADOOP-15696](HADOOP-15696.md) | `d1ea7df43d6` | clean | 默认 1s），防 FD 耗尽 |
| 中 | [HADOOP-15865](HADOOP-15865.md) | `72ef7528763` | 见文档 |  |
| 中 | [HADOOP-16028](HADOOP-16028.md) | `3dd40008846` | clean | NetworkTopology chooseRandom excludedScope 可用节点计数错误，带排除集选点死循环/错选 |
| 中 | [HADOOP-16127](HADOOP-16127.md) | `ce804be72e1` | 见文档 |  |
| 中 | [HADOOP-16161](HADOOP-16161.md) | `f1fe3abac9c` | 见文档 |  |
| 中 | [HADOOP-16192](HADOOP-16192.md) | `d4fbbc83ad8` | clean | ) 路径补检查、refreshCallQueue 后保留 backoff 开关 |
| 中 | [HADOOP-16248](HADOOP-16248.md) | `55cc35c0e14` | clean | MutableQuantiles scheduleAtFixedRate→scheduleWithFixedDelay，高负载内存泄漏/OOM |
| 中 | [HADOOP-16435](HADOOP-16435.md) | `4662b13b264` | 见文档 |  |
| 中 | [HADOOP-16459](HADOOP-16459.md) | `7b8f08f59e5` | 见文档 |  |
| 中 | [HADOOP-16461](HADOOP-16461.md) | `b9dc2c17de5` | 见文档 |  |
| 中 | [HADOOP-16580](HADOOP-16580.md) | `f8c06f5a87d` | 见文档 |  |
| 中 | [HADOOP-16677](HADOOP-16677.md) | `b4f39c2a8ac` | 见文档 |  |
| 中 | [HADOOP-16868](HADOOP-16868.md) | `b28347d2824` | 见文档 |  |
| 中 | [HADOOP-17052](HADOOP-17052.md) | `2c40f20debd` | clean | NetUtils.connect unchecked 异常 |
| 中 | [HADOOP-17342](HADOOP-17342.md) | `4cec4bebd9e` | clean | token 标识符去 kerberos 名称解析 |
| 中 | [HADOOP-17346](HADOOP-17346.md) | `c7845dc574c` | 冲突 | FairCallQueue 服务 principal 公平性 |
| 中 | [HDFS-10659](HDFS-10659.md) | `dd795edcc74` | clean | JN paxos 目录不存在时自动创建，防 NN 崩溃 |
| 中 | [HDFS-12703](HDFS-12703.md) | `fe40fbbd4d4` | 见文档 |  |
| 中 | [HDFS-12748](HDFS-12748.md) | `9c3806cf1b7` | 见文档 |  |
| 中 | [HDFS-12749](HDFS-12749.md) | `362657c1a35` | 见文档 |  |
| 中 | [HDFS-13027](HDFS-13027.md) | `65977e5d812` | clean | 遍历块补 isDeleted 检查 + fsck 补读锁 + BlockInfo.bcId volatile，防 NPE 竞态 |
| 中 | [HDFS-13566](HDFS-13566.md) | `3835a6c4e82` | 见文档 |  |
| 中 | [HDFS-13677](HDFS-13677.md) | `7b51edbab9f` | clean | 动态刷新磁盘配置 addAll 覆盖 VolumeMap，改 mergeAll 逐条合并 |
| 中 | [HDFS-13694](HDFS-13694.md) | `7c7907f756a` | 见文档 |  |
| 中 | [HDFS-13709](HDFS-13709.md) | `fc062b6fef9` | 见文档 |  |
| 中 | [HDFS-13840](HDFS-13840.md) | `02f8b5da47c` | clean | 低 GS RBW 报告标记 corrupt + 恢复副本补 addStoredBlock |
| 中 | [HDFS-13941](HDFS-13941.md) | `8548864ccb5` | clean | checkAccess 增加无 storageId token 的重载，DN 鉴权兼容升级期旧 token |
| 中 | [HDFS-13977](HDFS-13977.md) | `9dc921f5e5d` | 见文档 |  |
| 中 | [HDFS-14048](HDFS-14048.md) | `f65324aa47e` | clean | )，close 不再假报错 |
| 中 | [HDFS-14074](HDFS-14074.md) | `529d0955f5a` | 冲突 | ThrottledAsyncChecker completedChecks TOCTOU NPE 致 DN 注册失败 |
| 中 | [HDFS-14146](HDFS-14146.md) | `6c1bf616285` | 见文档 |  |
| 中 | [HDFS-14305](HDFS-14305.md) | `8fc4e406ad5` | 见文档 |  |
| 中 | [HDFS-14308](HDFS-14308.md) | `44ca2fe4db3` | 见文档 |  |
| 中 | [HDFS-14313](HDFS-14313.md) | `3aea2bcf120` | 见文档 |  |
| 中 | [HDFS-14314](HDFS-14314.md) | `d951497f57c` | clean | fullBlockReportLeaseId 提升为实例字段并在 register 后重置 |
| 中 | [HDFS-14317](HDFS-14317.md) | `b0b80002402` | 冲突 | in-progress tailing 下 lastRollTimeMs 独立计时+autoroll 阈值 0.5，保证 SNN checkpoint 生成 |
| 中 | [HDFS-14333](HDFS-14333.md) | `327e57ae6e4` | 冲突 | DN 注册时单盘错误整体启动失败，改 AddBlockPoolException+摘除坏盘继续启动 |
| 中 | [HDFS-14366](HDFS-14366.md) | `80732146c6f` | clean | N) getNumLiveDataNodes |
| 中 | [HDFS-14370](HDFS-14370.md) | `f6ce2f4a508` | 见文档 |  |
| 中 | [HDFS-14384](HDFS-14384.md) | `4690142e86b` | 见文档 |  |
| 中 | [HDFS-14459](HDFS-14459.md) | `163fb887a63` | 见文档 |  |
| 中 | [HDFS-14465](HDFS-14465.md) | `b3e0430c3be` | clean | 副本数>DN 数时 maintenance 永不退出 |
| 中 | [HDFS-14492](HDFS-14492.md) | `a3493fe3288` | 见文档 |  |
| 中 | [HDFS-14497](HDFS-14497.md) | `c61c114a3db` | 见文档 |  |
| 中 | [HDFS-14497](HDFS-14497.md) | `d91c68729c1` | 见文档 |  |
| 中 | [HDFS-14498](HDFS-14498.md) | `b6115597557` | clean | lease manager 无限循环，trunk 版 |
| 中 | [HDFS-14498](HDFS-14498.md) | `0bfd1b5a945` | clean | branch-3.1 backport，与 b6115597557 同 diff 重复，任选其一 |
| 中 | [HDFS-14523](HDFS-14523.md) | `41c0757a1f5` | 见文档 |  |
| 中 | [HDFS-14527](HDFS-14527.md) | `0160e2c97f7` | 见文档 |  |
| 中 | [HDFS-14547](HDFS-14547.md) | `a59553b5e6b` | 见文档 |  |
| 中 | [HDFS-14582](HDFS-14582.md) | `c2aeeb01fa6` | 见文档 |  |
| 中 | [HDFS-14610](HDFS-14610.md) | `d95dd33ea11` | 见文档 |  |
| 中 | [HDFS-14618](HDFS-14618.md) | `ab7ecd6a0f1` | 见文档 |  |
| 中 | [HDFS-14655](HDFS-14655.md) | `5c058549b71` | 见文档 |  |
| 中 | [HDFS-14687](HDFS-14687.md) | `92c3a581ec0` | 见文档 |  |
| 中 | [HDFS-14697](HDFS-14697.md) | `69e3ac5cbb2` | 见文档 |  |
| 中 | [HDFS-14706](HDFS-14706.md) | `63b18d764ae` | 见文档 |  |
| 中 | [HDFS-14852](HDFS-14852.md) | `0f234667dde` | clean | LowRedundancyBlocks 移除残留 |
| 中 | [HDFS-14853](HDFS-14853.md) | `8cc702ad38f` | 见文档 |  |
| 中 | [HDFS-14861](HDFS-14861.md) | `8aaa8d1b712` | 见文档 |  |
| 中 | [HDFS-15036](HDFS-15036.md) | `ea0eeb8f1ab` | 见文档 |  |
| 中 | [HDFS-15052](HDFS-15052.md) | `8095e3b149f` | 见文档 |  |
| 中 | [HDFS-15086](HDFS-15086.md) | `6a4297adc47` | 见文档 |  |
| 中 | [HDFS-15119](HDFS-15119.md) | `7dd43cec7f7` | 见文档 |  |
| 中 | [HDFS-15170](HDFS-15170.md) | `a09d636e2cd` | clean | EC 块 failover 误标 CORRUPT |
| 中 | [HDFS-15187](HDFS-15187.md) | `a68ca4a292a` | clean | failover 后 CORRUPT 副本不一致 |
| 中 | [HDFS-15199](HDFS-15199.md) | `64eb5b27094` | 见文档 |  |
| 中 | [HDFS-15250](HDFS-15250.md) | `86c15b82874` | clean | use.datanode.hostname 未解析异常 crash |
| 中 | [HDFS-15386](HDFS-15386.md) | `f701d7bdd18` | clean | 删多目录后 ReplicaNotFoundException 循环 |
| 中 | [HDFS-15403](HDFS-15403.md) | `c2f908482f2` | 冲突 | transferToSocketFully NPE |
| 中 | [HDFS-15415](HDFS-15415.md) | `4a8b59df595` | 冲突 | DirectoryScanner 减锁 |
| 中 | [HDFS-15422](HDFS-15422.md) | `bf229135caf` | clean | IBR 入队被 storedBlock 覆盖 |
| 中 | [HDFS-15621](HDFS-15621.md) | `71a9885c978` | 冲突 | DirectoryScanner ScanInfo 内存重构 |
| 中 | [HDFS-15622](HDFS-15622.md) | `7a3085d552c` | 冲突 | 已删块滞留复制队列 |
| 中 | [HDFS-15694](HDFS-15694.md) | `2331f86dfba` | clean | 心跳热路径去重复状态更新 |
| 中 | [HDFS-15703](HDFS-15703.md) | `521d5b381a9` | clean | no-op set 不写 edits |
| 中 | [HDFS-15709](HDFS-15709.md) | `173d298c637` | 冲突 | EC checksum socket FD 泄漏 |
| 中 | [HDFS-15725](HDFS-15725.md) | `e7df47c45c0` | 冲突 | lease recovery 永不完成 |
| 中 | [HDFS-15875](HDFS-15875.md) | `7250f0e3273` | 冲突 | truncate 竞态检查 |
| 中 | [HDFS-8178](HDFS-8178.md) | `e3c01e174c8` | 见文档 |  |
| 低 | [HADOOP-15864](HADOOP-15864.md) | `ef9f8ca13d8` | clean | use_ip 下 SBN 域名不可解析致 token service 构建抛异常、作业失败，改 warn+null |
| 低 | [HADOOP-16013](HADOOP-16013.md) | `7b4f44573f6` | 见文档 |  |
| 低 | [HADOOP-16126](HADOOP-16126.md) | `8d71b508abc` | 见文档 |  |
| 低 | [HADOOP-16208](HADOOP-16208.md) | `41f1bc20566` | clean | ipc Client 发送被打断时不再 warn 打日志，改抛 InterruptedIOException |
| 低 | [HADOOP-16307](HADOOP-16307.md) | `cf0d5a0e6ee` | clean | FileStatus owner/group weakIntern，客户端 listStatus GC 优化 |
| 低 | [HADOOP-16341](HADOOP-16341.md) | `2c4d8c343ea` | 见文档 |  |
| 低 | [HADOOP-16345](HADOOP-16345.md) | `cf3c1b9ffc8` | clean | FairCallQueue MetricsProxy delegate 为 null 时 NPE |
| 低 | [HADOOP-16662](HADOOP-16662.md) | `9434f36b436` | 见文档 |  |
| 低 | [HADOOP-16683](HADOOP-16683.md) | `3a09593a73c` | 见文档 |  |
| 低 | [HADOOP-16700](HADOOP-16700.md) | `23f25418e82` | 见文档 |  |
| 低 | [HADOOP-16705](HADOOP-16705.md) | `50d98a6568c` | 见文档 |  |
| 低 | [HADOOP-17127](HADOOP-17127.md) | `0de48933c50` | 冲突 | DecayRpcScheduler TIMEUNIT 一致性 |
| 低 | [HADOOP-17130](HADOOP-17130.md) | `cb3e3787820` | clean | getValByRegex 遍历时修改正确性 |
| 低 | [HADOOP-17358](HADOOP-17358.md) | `487eaa6dea1` | clean | Configuration 重复加载优化 |
| 低 | [HADOOP-17362](HADOOP-17362.md) | `118d8f5aa16` | clean | HAR ls 减少 RPC |
| 低 | [HADOOP-9844](HADOOP-9844.md) | `1b7c7dc860d` | 见文档 |  |
| 低 | [HDFS-11719](HDFS-11719.md) | `bff22305911` | clean | BlockSender.readChecksum 异常分支 Arrays.fill 下标错误修正 |
| 低 | [HDFS-12487](HDFS-12487.md) | `4507c2f3a5d` | clean | isValidBlock NPE 家族） |
| 低 | [HDFS-12999](HDFS-12999.md) | `354e63b366e` | 见文档 |  |
| 低 | [HDFS-13693](HDFS-13693.md) | `8ce5015e94b` | 见文档 |  |
| 低 | [HDFS-13721](HDFS-13721.md) | `7d1e2e1fbbe` | clean | DiskBalancer 未初始化时管理 RPC/JMX NPE 改明确 IOException |
| 低 | [HDFS-13730](HDFS-13730.md) | `fc8983a5b8c` | clean | BlockReaderRemote 错误路径 getRemoteAddressString NPE 掩盖原始 IOE |
| 低 | [HDFS-13735](HDFS-13735.md) | `e05b38f1322` | clean | 60s），防 tailing 无限阻塞 |
| 低 | [HDFS-13736](HDFS-13736.md) | `9956d18129c` | 见文档 |  |
| 低 | [HDFS-13758](HDFS-13758.md) | `7a115e8de47` | clean | getBlockRecoveryCommand 对无 UC feature 块抛 IOException 替代 assert/NPE |
| 低 | [HDFS-13789](HDFS-13789.md) | `d96ddb3b873` | 见文档 |  |
| 低 | [HDFS-13791](HDFS-13791.md) | `91803c82167` | 见文档 |  |
| 低 | [HDFS-13831](HDFS-13831.md) | `2cbc3c7d43c` | clean | dfs.namenode.block.deletion.increment 可配置，写锁分批粒度可调 |
| 低 | [HDFS-13901](HDFS-13901.md) | `8ef6c0aab24` | 见文档 |  |
| 低 | [HDFS-14027](HDFS-14027.md) | `399645ebc16` | clean | EnumSet) |
| 低 | [HDFS-14043](HDFS-14043.md) | `9bf4f3d6140` | clean | seen_txid 损坏时 NumberFormatException 包装为 IOException 走容错路径 |
| 低 | [HDFS-14171](HDFS-14171.md) | `f24684ca9cd` | clean | safemode areThresholdsMet 在 datanodeThreshold=0 时跳过 getNumLiveDataNodes |
| 低 | [HDFS-14235](HDFS-14235.md) | `1030ac85bbf` | 见文档 |  |
| 低 | [HDFS-14247](HDFS-14247.md) | `90b88db35d4` | 见文档 |  |
| 低 | [HDFS-14263](HDFS-14263.md) | `bd9e2826fec` | clean | ) 磁盘检查 |
| 低 | [HDFS-14276](HDFS-14276.md) | `900384cf57a` | 见文档 |  |
| 低 | [HDFS-14311](HDFS-14311.md) | `7a1f508f582` | 见文档 |  |
| 低 | [HDFS-14535](HDFS-14535.md) | `b082628e5a3` | clean | 短读 requestFileDescriptors 8KB 缓冲降 512B，HBase 堆分配/GC 优化 |
| 低 | [HDFS-14537](HDFS-14537.md) | `3ba7826d41e` | 见文档 |  |
| 低 | [HDFS-14541](HDFS-14541.md) | `aaf74ea5d73` | 见文档 |  |
| 低 | [HDFS-14553](HDFS-14553.md) | `03ec4c4c7c1` | 冲突 | BlockReportProcessingThread 队列大小可配置 dfs.namenode.blockreport.queue.size |
| 低 | [HDFS-14578](HDFS-14578.md) | `12b258115b4` | 见文档 |  |
| 低 | [HDFS-14631](HDFS-14631.md) | `d66ee4bf611` | 见文档 |  |
| 低 | [HDFS-14632](HDFS-14632.md) | `2e1afa9a867` | 见文档 |  |
| 低 | [HDFS-14637](HDFS-14637.md) | `71dcb8f6d40` | 见文档 |  |
| 低 | [HDFS-14720](HDFS-14720.md) | `91790463684` | 见文档 |  |
| 低 | [HDFS-14731](HDFS-14731.md) | `4af188587fa` | 见文档 |  |
| 低 | [HDFS-14806](HDFS-14806.md) | `76ca8644067` | 见文档 |  |
| 低 | [HDFS-14859](HDFS-14859.md) | `a3599c7e705` | 见文档 |  |
| 低 | [HDFS-14909](HDFS-14909.md) | `14beaae65e6` | 见文档 |  |
| 低 | [HDFS-14913](HDFS-14913.md) | `9067a11b0d0` | 见文档 |  |
| 低 | [HDFS-14915](HDFS-14915.md) | `4d4f5325bde` | 见文档 |  |
| 低 | [HDFS-14952](HDFS-14952.md) | `d101b748142` | 见文档 |  |
| 低 | [HDFS-14986](HDFS-14986.md) | `f1a19b7a3f5` | 见文档 |  |
| 低 | [HDFS-15010](HDFS-15010.md) | `5eb21b83dfd` | 见文档 |  |
| 低 | [HDFS-15032](HDFS-15032.md) | `b06965ae32c` | 见文档 |  |
| 低 | [HDFS-15074](HDFS-15074.md) | `55510d32bf0` | 见文档 |  |
| 低 | [HDFS-15161](HDFS-15161.md) | `83ab8537338` | 见文档 |  |
| 低 | [HDFS-15174](HDFS-15174.md) | `268e35d3ae7` | 见文档 |  |
| 低 | [HDFS-15281](HDFS-15281.md) | `68dcdad6662` | clean | ZKFC 按 rpc-address 绑定 |
| 低 | [HDFS-15293](HDFS-15293.md) | `8f53545f9d1` | 冲突 | checkpoint fsimage 接收校验放宽 |
| 低 | [HDFS-15295](HDFS-15295.md) | `6f7a30fd716` | 冲突 | AvailableSpace 策略 two-trial |
| 低 | [HDFS-15406](HDFS-15406.md) | `9d891f08c28` | clean | DN block scan 提速 |
| 低 | [HDFS-15446](HDFS-15446.md) | `1e0424f39a5` | clean | raw 路径 snapshot 编辑日志加载失败 |
| 低 | [HDFS-15574](HDFS-15574.md) | `43b113de69a` | clean | DirectoryScanner 去排序 |
| 低 | [HDFS-15583](HDFS-15583.md) | `27b2c1ea7bb` | 冲突 | DirectoryScanner 三修复回移 |
| 低 | [HDFS-15618](HDFS-15618.md) | `33db7c140b3` | 冲突 | DN 停机延迟优化 |
| 低 | [HDFS-15623](HDFS-15623.md) | `3443d759468` | clean | setProtocolEngine 尊重 rpc.engine 配置 |
| 低 | [HDFS-15633](HDFS-15633.md) | `8354ce680b8` | clean | getDiskStatus 3 RPC 降为 1 |
| 低 | [HDFS-15734](HDFS-15734.md) | `09bbbc8b866` | 冲突 | DirectoryScanner 微优化 |
| 低 | [HDFS-15783](HDFS-15783.md) | `33a71c8b9e5` | clean | verifyBlockPlacement 提速 |
| 低 | [HDFS-15826](HDFS-15826.md) | `cab9172d2e3` | clean | fsimage 加载 token 序号推进 |
| 低 | [HDFS-16040](HDFS-16040.md) | `a357d4ce607` | 冲突 | RpcQueueTime 重排队重复计数修复 |
| 低 | [HDFS-16233](HDFS-16233.md) | `cd7c34f9b40` | 冲突 | 用户点名；QuotaCounts 去异常驱动 COW |

## 之前验证清单在新基线下的状态（KNOWN 13 个）

**新基线 680dac26 仍缺失，恢复 pick 资格**：HADOOP-10219、HDFS-13051、HADOOP-15684、HDFS-13768+13962、HDFS-15211、HDFS-15219、HDFS-14973、HDFS-15068、HDFS-14920、HDFS-15115、HADOOP-16531（+ 之前 trunk 侧 HADOOP-15340、15611、15742、HDFS-13833 不在本 range，结论不变）

**已在基线**：HDFS-13792（patch 等价存在于 branch-3.1）

## 注意事项

- **HDFS-14497**：主修复 + addendum 两个 commit 须一起 pick
- **HDFS-14498**：两个 hash（`b6115597557`/`0bfd1b5a945`）同 diff，取一
- **HDFS-14909 + HDFS-14913**：同改 `chooseRandomWithStorageType`，按序合并
- **HDFS-15295**：pick 前确认基线有 `chooseRandomWithStorageTypeTwoTrial`
- **HDFS-16233**：用户点名（QuotaCounts 去异常驱动 COW），apply 冲突 `QuotaCounts.java`，需手工合
- **HDFS-13813**（`b38649c59a7`）：当前 HEAD 已 revert，跳过
- **HADOOP-16459 + 16531**：慢 RPC 计时指标，前置+本体配对 pick
- 评级分布：高 18 / 中 80 / 低 74；apply clean 约半，冲突多集中在测试文件或与基线漂移的大文件（DirectoryScanner、DecayRpcScheduler、BlockManager 等），主代码 hunk 大多可手工合
